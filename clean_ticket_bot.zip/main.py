
import discord
import json
import asyncio
import requests
from bs4 import BeautifulSoup

with open("config.json", "r") as f:
    config = json.load(f)

TOKEN = config["discord_token"]
CHANNEL_ID = int(config["channel_id"])
MONITOR_URLS = config["monitor_targets"]

intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

notified_flags = [False for _ in MONITOR_URLS]

@client.event
async def on_ready():
    print(f"🤖 機器人已上線：{client.user}")
    channel = client.get_channel(CHANNEL_ID)
    await channel.send("✅ 清票通知機器人已上線，正在守株待兔等清票！")
    while True:
        for idx, item in enumerate(MONITOR_URLS):
            try:
                res = requests.get(item["url"], headers={"User-Agent": "Mozilla/5.0"})
                soup = BeautifulSoup(res.text, "html.parser")
                if "尚有票" in soup.text or "立即訂票" in soup.text or "票券資訊" in soup.text:
                    if not notified_flags[idx]:
                        embed = discord.Embed(title=f"🎟️ 清票啦！ {item['name']}", description=f"👉 [立即購票]({item['url']})", color=0xF39C12)
                        await channel.send("@everyone", embed=embed)
                        notified_flags[idx] = True
                else:
                    notified_flags[idx] = False
            except Exception as e:
                print(f"⚠️ 錯誤：{e}")
        await asyncio.sleep(1)

@client.event
async def on_message(message):
    if message.content == "!票況":
        await message.channel.send("🎯 正在監控的演唱會：\n" + "\n".join([f"- {t['name']}" for t in MONITOR_URLS]))

client.run(TOKEN)
